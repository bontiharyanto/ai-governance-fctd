# 📊 Data Sheet for Dataset

## Informasi Dataset
- **Nama Dataset**:  
- **Versi**:  
- **Sumber**:  
- **Tanggal Dibuat**:  

## Tujuan
Use case dataset ini dan keterbatasannya.

## Komposisi Data
- Ukuran dataset.  
- Distribusi kategori/demografi.  
- Potensi bias.  

## Proses Pengumpulan
- Metode pengumpulan.  
- Izin & consent.  

## Etika & Kepatuhan
- Kepatuhan ke UU PDP.  
- Retensi & hak akses data.  

## Referensi
- Gebru et al., *Datasheets for Datasets* (2018).  
- UU PDP 2022.
