# 🛡️ Red Teaming Report

## Identitas
- **Sistem yang diuji**:  
- **Tanggal Uji**:  
- **Tim Penanggung Jawab**:  

## Metodologi
- Jenis serangan (prompt injection, adversarial input, data poisoning).  
- Tools yang digunakan.  

## Hasil Uji
- Kerentanan ditemukan.  
- Dampak potensial.  
- Reproduksi langkah.  

## Rekomendasi
- Patch teknis.  
- Proses pencegahan ke depan.  
- Monitoring tambahan.  

## Referensi
- NIST AI RMF (Risk Management)  
- MITRE ATLAS (Adversarial Threat Landscape for AI)  
- COBIT DSS05 (Security Services)
