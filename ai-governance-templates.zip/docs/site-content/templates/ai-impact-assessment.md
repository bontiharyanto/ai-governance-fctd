# 📝 AI Impact Assessment (AIA)

## Informasi Umum
- **Nama Sistem AI**:  
- **Pemilik Sistem**:  
- **Tanggal Penilaian**:  
- **Versi Model**:  

## Tujuan & Ruang Lingkup
- Use case & manfaat bisnis.  
- Potensi dampak terhadap individu & masyarakat.  

## Analisis Risiko
- **Risiko Teknis**: bias, drift, robustness.  
- **Risiko Legal**: UU PDP, POJK 13/2021.  
- **Risiko Etis**: fairness, explainability.  

## Mitigasi
- Kontrol teknis & non-teknis.  
- Proses monitoring & evaluasi.  

## Keputusan
- ✅ Disetujui untuk produksi.  
- ⚠️ Perlu mitigasi tambahan.  
- ❌ Ditolak.

---
**Referensi**  
- NIST AI RMF (Govern)  
- STRANAS AI Indonesia (2020)  
- EU AI Act (draft) sebagai benchmarking
