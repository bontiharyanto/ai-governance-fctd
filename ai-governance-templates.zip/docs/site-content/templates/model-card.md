# 📑 Model Card

## Informasi Model
- **Nama Model**:  
- **Versi**:  
- **Tanggal Rilis**:  
- **Pemilik Model**:  

## Deskripsi
Ringkasan fungsi dan tujuan model.

## Data & Training
- Dataset & sumber data.  
- Metode preprocessing.  
- Distribusi demografis.  

## Evaluasi
- Akurasi (top-line metric).  
- Fairness metrics.  
- Robustness checks.  

## Keterbatasan
- Kondisi di mana model tidak boleh digunakan.  
- Potensi bias yang diketahui.  

## Referensi
- Mitchell et al., *Model Cards for Model Reporting* (Google AI, 2019).  
- NIST AI RMF – Transparency.
