# Prompt Management

Manajemen prompt merupakan kontrol penting untuk mencegah **hallucination** dan memastikan jawaban AI relevan.

- **Framework**: NIST AI RMF, COBIT DSS05  
- **Praktik**: Logging prompt, validasi query, RAG (Retrieval-Augmented Generation)
