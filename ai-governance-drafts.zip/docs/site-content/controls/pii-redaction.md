# PII Redaction

Perlindungan data pribadi sesuai UU PDP & POJK.

- Masking otomatis untuk data sensitif  
- Data minimization  
- Audit akses
