# AI Lifecycle

Mengacu pada TOGAF ADM & NIST AI RMF.

1. **Inisiasi** – identifikasi kebutuhan bisnis.  
2. **Desain** – model governance & risk control.  
3. **Pengembangan** – MLOps pipeline.  
4. **Monitoring** – deteksi drift, audit trail.  
5. **Retiring** – dokumentasi, arsip model.
