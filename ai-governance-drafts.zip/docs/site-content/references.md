# 📚 Referensi

- The Open Group. (2018). *TOGAF® Standard, Version 9.2*.  
- ISACA. (2019). *COBIT® 2019 Framework: Governance and Management Objectives*.  
- National Institute of Standards and Technology. (2023). *AI Risk Management Framework (AI RMF 1.0)*.  
- Republik Indonesia. (2022). *Undang-Undang Nomor 27 Tahun 2022 tentang Perlindungan Data Pribadi*.  
- Otoritas Jasa Keuangan. (2021). *POJK No. 13/POJK.03/2021 tentang Penyelenggaraan Teknologi Informasi*.  
- Kementerian Riset & Teknologi / BRIN. (2020). *Strategi Nasional Kecerdasan Artifisial Indonesia 2020–2045*.  
- ISO/IEC. (2023). *ISO/IEC 42001: Artificial Intelligence Management System Standard*.  
