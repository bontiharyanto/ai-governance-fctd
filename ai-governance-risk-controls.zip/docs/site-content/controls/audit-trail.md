# 🧾 Audit Trail AI Systems

Audit trail adalah rekaman aktivitas sistem untuk kepatuhan dan investigasi.

## Framework Rujukan
- COBIT DSS06 (Manage Business Process Controls).  
- UU PDP (Hak Akses & Keamanan Data).  

## Implementasi
- Logging interaksi pengguna & model.  
- Immutable storage (WORM / blockchain).  
- Akses terbatas untuk regulator/internal audit.
