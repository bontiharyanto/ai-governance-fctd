# 👥 Roles & Responsibilities (RACI Matrix)

Dokumen ini mendefinisikan peran dan tanggung jawab utama dalam tata kelola AI.

## RACI Matrix

| Role                | Accountable | Responsible | Consulted | Informed |
|---------------------|-------------|-------------|-----------|----------|
| Board of Directors  | ✅           |             |           |          |
| CISO (Chief InfoSec)| ✅           | ✅           |           |          |
| DPO (Data Protection Officer) | ✅ |             |           | ✅        |
| AI Model Owner      |             | ✅           | ✅         |          |
| MLOps Engineer      |             | ✅           | ✅         |          |
| Compliance Officer  | ✅           |             | ✅         | ✅        |

## Framework Rujukan
- COBIT APO01 (Manage the IT Management Framework).  
- NIST AI RMF (Governance).  
- UU PDP 2022 (Data Protection Roles).  

## Catatan
- Harus ada *Human-in-the-loop* untuk AI High-Risk Use Cases.  
- Semua role wajib masuk dalam *training & awareness program*.
