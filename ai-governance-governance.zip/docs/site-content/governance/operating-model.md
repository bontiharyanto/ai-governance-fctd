# 🏛️ AI Governance Operating Model

Operating model menjelaskan struktur dan mekanisme pengelolaan tata kelola AI di organisasi.

## Struktur Organisasi
- **AI Governance Committee**: gabungan fungsi Risk, Compliance, IT, dan Business.  
- **Three Lines of Defense**:  
  1. Operasional (unit bisnis, AI owner).  
  2. Risk & Compliance oversight.  
  3. Internal Audit & Regulators.

## Mekanisme
- **Model Approval Process** (design → validation → deployment).  
- **Risk Assessment**: setiap model melewati *AI Impact Assessment*.  
- **Review Periodik**: minimal 6 bulan sekali.

## Framework Rujukan
- TOGAF (Architecture Governance).  
- COBIT EDM01 (Governance Framework Setting and Maintenance).  
- POJK 13/2021 (Tata Kelola TI).  
- STRANAS AI Indonesia (Etika & Tata Kelola).  

## Catatan
- Operating Model wajib selaras dengan Enterprise Architecture.  
- Harus ada *escalation path* bila risiko AI high severity ditemukan.
